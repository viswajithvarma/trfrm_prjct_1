# main.py
def hello_world(request):
    return "Hello from Terraform!"